#!/bin/bash

while :
do
	:
done
