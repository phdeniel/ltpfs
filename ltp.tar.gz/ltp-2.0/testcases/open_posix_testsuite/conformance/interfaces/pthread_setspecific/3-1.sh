#!/bin/sh
# Copyright (c) 2002, Intel Corporation. All rights reserved.
# Created by:  rolla.n.selbak REMOVE-THIS AT intel DOT com
# This file is licensed under the GPL license.  For the full content
# of this license, see the COPYING file at the top level of this
# source tree.

#  Test void *pthread_setspecific(pthread_key_t key)
#  It returns 0 upon success, and an error number otherwise:

# This is tested implicitly via assertion 1.

echo "Tested implicitly via assertions 1.  See output for status"
exit 0
