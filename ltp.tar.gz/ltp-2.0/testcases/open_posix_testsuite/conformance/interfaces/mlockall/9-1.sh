#! /bin/sh
#
# Test that the mlockall() function return -1 upon unsuccessful completion.
#
# This is tested implicitly via assertions 12 to 15.

echo "Tested implicitly via assertions 12 to 15."
exit 0
