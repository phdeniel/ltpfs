#! /bin/sh
#
# Test that the appropriate privilege is required to lock process memory with
# mlockall()
#
# This is tested implicitly via assertion 15.

echo "Tested implicitly via assertion 15."
exit 0
