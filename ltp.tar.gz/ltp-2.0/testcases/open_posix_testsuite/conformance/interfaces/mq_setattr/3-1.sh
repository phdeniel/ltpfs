#!/bin/sh
# Copyright (c) 2003, Intel Corporation. All rights reserved.
# Created by:  crystal.xiong REMOVE-THIS AT intel DOT com
# This file is licensed under the GPL license.  For the full content
# of this license, see the COPYING file at the top level of this
# source tree.


# Test if mq_setattr is success, mq_setattr will return a value of
# 0 and the attributes of the message queue will change as specified.

# This is tested implicitly via assertion 1.

echo "Tested implicitly via assertion 1.  See output for status"
exit 0
