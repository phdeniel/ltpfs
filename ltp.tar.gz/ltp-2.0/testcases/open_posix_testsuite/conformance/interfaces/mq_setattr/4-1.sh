#!/bin/sh
# Copyright (c) 2003, Intel Corporation. All rights reserved.
# Created by:  crystal.xiong REMOVE-THIS AT intel DOT com
# This file is licensed under the GPL license.  For the full content
# of this license, see the COPYING file at the top level of this
# source tree.


# If mq_setattr() is not sucessful, the message queue attributes will
# not change, the function will return -1 nd set errno to indicate the error.

# This is tested implicitly via assertion 5.

echo "Tested implicitly via assertion 5.  See output for status"
exit 0
