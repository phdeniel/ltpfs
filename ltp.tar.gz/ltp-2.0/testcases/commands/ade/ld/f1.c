
void f1()
{
	int i = 69;
	i = i;
	return;
}
