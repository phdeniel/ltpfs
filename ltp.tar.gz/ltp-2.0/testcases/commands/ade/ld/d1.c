int d1 = 1;
