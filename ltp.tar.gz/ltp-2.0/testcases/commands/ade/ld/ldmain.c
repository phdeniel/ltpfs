#include <stdio.h>
#include <stdlib.h>

extern void use_s1();

int main()
{
	use_s1();
	return (0);
}
