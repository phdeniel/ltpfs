#include <stdio.h>
void file1()
{
	printf("Control in function %s\n", __func__);
}
