#include <stdio.h>

void file1();
void file2();
void file3();
void file4();
void file5();

int main()
{
	file1();
	file2();
	file3();
	file4();
	file5();
	printf("All Functions Executed\n");
	return 0;
}
