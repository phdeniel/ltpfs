#include <stdio.h>
void file4()
{
	printf("Control in function %s\n", __func__);
}
