#include <stdio.h>
void file3()
{
	printf("Control in function %s\n", __func__);
}
