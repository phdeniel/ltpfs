#include <stdio.h>
void file2()
{
	printf("Control in function %s\n", __func__);
}
