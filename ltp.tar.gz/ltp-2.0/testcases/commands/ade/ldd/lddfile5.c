#include <stdio.h>
void file5()
{
	printf("Control in function %s\n", __func__);
}
